# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
import numpy as np
import pandas as pd
from datetime import datetime, timedelta, timezone
from pandas import DataFrame
from typing import Dict, Optional, Union, Tuple

from freqtrade.strategy import (
    IStrategy,
    Trade,
    Order,
    PairLocks,
    informative,
    BooleanParameter,
    CategoricalParameter,
    DecimalParameter,
    IntParameter,
    RealParameter,
    timeframe_to_minutes,
    timeframe_to_next_date,
    timeframe_to_prev_date,
    merge_informative_pair,
    stoploss_from_absolute,
    stoploss_from_open,
    AnnotationType,
)

import talib.abstract as ta
from technical import qtpylib


class LiquidationHuntStrategy(IStrategy):
    """
    Liquidation-based mean reversion strategy.
    
    CONCEPT: 
    - Detects sharp price drops (liquidation cascades of longs)
    - Enters when panic selling exhausted (high volume + oversold)
    - Targets bounce back as shorts cover and market stabilizes
    
    TIMEFRAME: 15m - best balance for catching liquidation moves
    Also good on: 5m (faster), 1h (swing trades)
    """
    
    INTERFACE_VERSION = 3

    # 15-minute timeframe - optimal for liquidation detection
    # Alternatives: 5m (more aggressive), 1h (swing trading)
    timeframe = "15m"
    
    can_short: bool = False

    # Aggressive ROI - capture quick bounces after liquidations
    minimal_roi = {
        "0": 0.06,      # 6% target (liquidation bounces are strong)
        "30": 0.04,     # 4% after 30 min
        "60": 0.025,    # 2.5% after 1 hour
        "120": 0.015,   # 1.5% after 2 hours
        "240": 0.008    # 0.8% after 4 hours
    }

    # Stop loss - protect against continuation of dump
    stoploss = -0.035  # 3.5% stop

    # Trailing stop to lock in bounce profits
    trailing_stop = True
    trailing_only_offset_is_reached = True
    trailing_stop_positive = 0.012   # Start trailing at 1.2%
    trailing_stop_positive_offset = 0.025  # Offset 2.5%

    process_only_new_candles = True

    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    startup_candle_count: int = 100

    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False
    }

    order_time_in_force = {
        "entry": "GTC",
        "exit": "GTC"
    }

    @property
    def plot_config(self):
        return {
            "main_plot": {
                "bb_lowerband": {"color": "red"},
                "bb_middleband": {"color": "blue"},
                "bb_upperband": {"color": "green"},
            },
            "subplots": {
                "RSI": {
                    "rsi": {"color": "red"},
                },
                "Volume": {
                    "volume": {"color": "blue"},
                    "volume_mean": {"color": "orange"},
                },
                "Liquidation Signal": {
                    "volume_spike": {"color": "purple"},
                    "price_drop": {"color": "red"},
                }
            }
        }

    def informative_pairs(self):
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Indicators for liquidation detection:
        - Volume spikes (liquidation cascades)
        - Sharp price drops
        - Oversold conditions (RSI, Bollinger)
        - Momentum exhaustion
        """
        
        # === LIQUIDATION DETECTION ===
        
        # Volume analysis - liquidations create massive volume
        dataframe["volume_mean_short"] = dataframe["volume"].rolling(window=10).mean()
        dataframe["volume_mean"] = dataframe["volume"].rolling(window=20).mean()
        dataframe["volume_spike"] = dataframe["volume"] / dataframe["volume_mean"]
        
        # Sharp price drops - liquidation cascades
        dataframe["price_drop_1"] = (dataframe["close"] - dataframe["close"].shift(1)) / dataframe["close"].shift(1) * 100
        dataframe["price_drop_3"] = (dataframe["close"] - dataframe["close"].shift(3)) / dataframe["close"].shift(3) * 100
        dataframe["price_drop_5"] = (dataframe["close"] - dataframe["close"].shift(5)) / dataframe["close"].shift(5) * 100
        
        # Candle wicks - signs of rejection/absorption
        dataframe["lower_wick"] = (dataframe["low"] - dataframe[["open", "close"]].min(axis=1)) / dataframe["close"] * 100
        dataframe["upper_wick"] = (dataframe["high"] - dataframe[["open", "close"]].max(axis=1)) / dataframe["close"] * 100
        
        # === OVERSOLD / REVERSAL INDICATORS ===
        
        # RSI - multiple timeframes
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["rsi_fast"] = ta.RSI(dataframe, timeperiod=7)
        
        # Stochastic - oversold detection
        stoch = ta.STOCH(dataframe, fastk_period=14, slowk_period=3, slowd_period=3)
        dataframe["stoch_k"] = stoch["slowk"]
        dataframe["stoch_d"] = stoch["slowd"]
        
        # Bollinger Bands - volatility and extremes
        bollinger = qtpylib.bollinger_bands(qtpylib.typical_price(dataframe), window=20, stds=2.5)
        dataframe["bb_lowerband"] = bollinger["lower"]
        dataframe["bb_middleband"] = bollinger["mid"]
        dataframe["bb_upperband"] = bollinger["upper"]
        dataframe["bb_percent"] = (
            (dataframe["close"] - dataframe["bb_lowerband"]) /
            (dataframe["bb_upperband"] - dataframe["bb_lowerband"])
        )
        dataframe["bb_width"] = (
            (dataframe["bb_upperband"] - dataframe["bb_lowerband"]) / dataframe["bb_middleband"]
        )
        
        # Williams %R - oversold
        dataframe["willr"] = ta.WILLR(dataframe, timeperiod=14)
        
        # === TREND / MOMENTUM ===
        
        # EMAs for trend context
        dataframe["ema_20"] = ta.EMA(dataframe, timeperiod=20)
        dataframe["ema_50"] = ta.EMA(dataframe, timeperiod=50)
        dataframe["ema_200"] = ta.EMA(dataframe, timeperiod=200)
        
        # MACD for momentum
        macd = ta.MACD(dataframe, fastperiod=12, slowperiod=26, signalperiod=9)
        dataframe["macd"] = macd["macd"]
        dataframe["macdsignal"] = macd["macdsignal"]
        dataframe["macdhist"] = macd["macdhist"]
        
        # ADX for trend strength
        dataframe["adx"] = ta.ADX(dataframe, timeperiod=14)
        
        # MFI - Money Flow Index (volume-weighted RSI)
        dataframe["mfi"] = ta.MFI(dataframe, timeperiod=14)
        
        # ATR for volatility
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=14)
        dataframe["atr_percent"] = (dataframe["atr"] / dataframe["close"]) * 100
        
        # === COMPOSITE SIGNALS ===
        
        # Liquidation score (0-100)
        dataframe["liq_score"] = 0
        
        # Volume component (0-40 points)
        dataframe.loc[dataframe["volume_spike"] > 2.0, "liq_score"] += 10
        dataframe.loc[dataframe["volume_spike"] > 2.5, "liq_score"] += 10
        dataframe.loc[dataframe["volume_spike"] > 3.0, "liq_score"] += 10
        dataframe.loc[dataframe["volume_spike"] > 4.0, "liq_score"] += 10
        
        # Price drop component (0-30 points)
        dataframe.loc[dataframe["price_drop_3"] < -2, "liq_score"] += 10
        dataframe.loc[dataframe["price_drop_3"] < -3, "liq_score"] += 10
        dataframe.loc[dataframe["price_drop_5"] < -4, "liq_score"] += 10
        
        # Oversold component (0-30 points)
        dataframe.loc[dataframe["rsi"] < 35, "liq_score"] += 10
        dataframe.loc[dataframe["rsi"] < 25, "liq_score"] += 10
        dataframe.loc[dataframe["bb_percent"] < 0.2, "liq_score"] += 10

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        ENTRY LOGIC: Buy after liquidation cascade when reversal signs appear
        
        CONDITIONS:
        1. Sharp price drop detected (liquidation event)
        2. Extreme volume spike
        3. Deep oversold (RSI, Stochastic, BB)
        4. Signs of reversal (long wick, bouncing candle)
        """
        dataframe.loc[
            (
                # === PRIMARY: LIQUIDATION EVENT DETECTED ===
                
                # Massive volume spike (liquidation cascade)
                (dataframe["volume_spike"] > 2.2) &
                
                # Sharp recent price drop
                (
                    (dataframe["price_drop_3"] < -2.0) |  # 2%+ drop in 3 candles
                    (dataframe["price_drop_5"] < -3.5)    # OR 3.5%+ drop in 5 candles
                ) &
                
                # === SECONDARY: OVERSOLD CONDITIONS ===
                
                # RSI deeply oversold
                (dataframe["rsi"] < 38) &
                (dataframe["rsi_fast"] < 35) &
                
                # Stochastic oversold
                (dataframe["stoch_k"] < 25) &
                
                # Below lower Bollinger Band (panic selling)
                (dataframe["close"] <= dataframe["bb_lowerband"] * 1.01) &
                
                # Williams %R oversold
                (dataframe["willr"] < -75) &
                
                # === TERTIARY: REVERSAL SIGNS ===
                
                (
                    # Long lower wick (buyers stepping in)
                    (dataframe["lower_wick"] > 0.8) |
                    
                    # Current candle bouncing up
                    (
                        (dataframe["close"] > dataframe["open"]) &  # Green candle
                        (dataframe["close"] > dataframe["close"].shift(1))  # Higher than prev
                    ) |
                    
                    # MFI showing money flowing in
                    (
                        (dataframe["mfi"] < 25) &
                        (dataframe["mfi"] > dataframe["mfi"].shift(1))  # Starting to rise
                    )
                ) &
                
                # === FILTERS ===
                
                # Not in extreme downtrend (price not too far from EMAs)
                (dataframe["close"] > dataframe["ema_200"] * 0.85) &
                
                # Volatility check (ATR reasonable)
                (dataframe["atr_percent"] < 8) &
                
                # Volume confirmation
                (dataframe["volume"] > 0)
            ),
            "enter_long"] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        EXIT LOGIC: Exit when bounce completes or reverses
        
        EXIT CONDITIONS:
        1. Price reaches overbought (bounce exhausted)
        2. Momentum weakening
        3. Volume declining (buying pressure done)
        """
        dataframe.loc[
            (
                (
                    # RSI overbought - bounce done
                    (dataframe["rsi"] > 68) |
                    
                    # Back to upper Bollinger Band
                    (
                        (dataframe["close"] >= dataframe["bb_upperband"] * 0.98) &
                        (dataframe["close"] < dataframe["open"])  # Red candle at resistance
                    ) |
                    
                    # MACD turning negative
                    (
                        (dataframe["macd"] < dataframe["macdsignal"]) &
                        (dataframe["macdhist"] < 0) &
                        (dataframe["macdhist"] < dataframe["macdhist"].shift(1))  # Weakening
                    ) |
                    
                    # Momentum exhaustion - RSI divergence
                    (
                        (dataframe["rsi"] > 60) &
                        (dataframe["rsi"] < dataframe["rsi"].shift(1)) &
                        (dataframe["rsi"].shift(1) < dataframe["rsi"].shift(2)) &  # 2 candles declining RSI
                        (dataframe["close"] > dataframe["close"].shift(2))  # But price still higher (divergence)
                    ) |
                    
                    # Sharp rejection - large upper wick
                    (
                        (dataframe["upper_wick"] > 1.2) &
                        (dataframe["close"] < dataframe["open"]) &
                        (dataframe["rsi"] > 55)
                    )
                ) &
                
                (dataframe["volume"] > 0)
            ),
            "exit_long"] = 1

        return dataframe

    def confirm_trade_entry(self, pair: str, order_type: str, amount: float, rate: float,
                           time_in_force: str, current_time: datetime, entry_tag: Optional[str],
                           side: str, **kwargs) -> bool:
        """
        Additional entry confirmation - can add external liquidation data here
        """
        return True