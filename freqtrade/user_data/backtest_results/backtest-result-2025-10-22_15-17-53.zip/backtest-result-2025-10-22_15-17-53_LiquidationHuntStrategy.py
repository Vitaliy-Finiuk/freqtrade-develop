# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
import numpy as np
import pandas as pd
from pandas import DataFrame
from typing import Dict, Optional
from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter, BooleanParameter
import talib.abstract as ta
from technical import qtpylib


class LiquidationHuntStrategy(IStrategy):
    """
    Liquidation Hunt Strategy - Improved version
    """
    
    INTERFACE_VERSION = 3
    timeframe = "15m"
    can_short = False

    # ROI configuration
    minimal_roi = {
        "0": 0.05,
        "20": 0.03,
        "40": 0.02,
        "60": 0.01
    }

    # Stoploss
    stoploss = -0.04

    # Trailing stop
    trailing_stop = True
    trailing_only_offset_is_reached = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02

    # Strategy parameters
    volume_spike_threshold = DecimalParameter(1.5, 2.5, default=1.8, space="buy")
    rsi_oversold_threshold = IntParameter(30, 45, default=35, space="buy")
    price_drop_threshold = DecimalParameter(-3.0, -1.0, default=-1.8, space="buy")

    process_only_new_candles = True
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False
    startup_candle_count = 100

    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False
    }

    order_time_in_force = {
        "entry": "GTC",
        "exit": "GTC"
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Volume analysis
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()
        dataframe['volume_ratio'] = dataframe['volume'] / dataframe['volume_mean']
        
        # Price movements
        dataframe['price_change_3'] = (dataframe['close'] - dataframe['close'].shift(3)) / dataframe['close'].shift(3) * 100
        dataframe['price_change_5'] = (dataframe['close'] - dataframe['close'].shift(5)) / dataframe['close'].shift(5) * 100
        
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_fast'] = ta.RSI(dataframe, timeperiod=7)
        
        # Bollinger Bands
        bollinger = qtpylib.bollinger_bands(qtpylib.typical_price(dataframe), window=20, stds=2)
        dataframe['bb_lowerband'] = bollinger['lower']
        dataframe['bb_upperband'] = bollinger['upper']
        
        # Stochastic
        stoch = ta.STOCH(dataframe)
        dataframe['stoch_k'] = stoch['slowk']
        dataframe['stoch_d'] = stoch['slowd']
        
        # EMA
        dataframe['ema_20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        
        # Candle wicks
        dataframe['lower_wick'] = (dataframe[['open', 'close']].min(axis=1) - dataframe['low']) / dataframe['close'] * 100
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['volume_ratio'] > self.volume_spike_threshold.value) &
                (dataframe['price_change_3'] < self.price_drop_threshold.value) &
                (dataframe['rsi'] < self.rsi_oversold_threshold.value) &
                (dataframe['close'] <= dataframe['bb_lowerband']) &
                (dataframe['volume'] > 0)
            ),
            'enter_long'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi'] > 65) |
                (dataframe['close'] >= dataframe['bb_upperband'])
            ),
            'exit_long'
        ] = 1

        return dataframe