# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
# --- Do not remove these imports ---
import numpy as np
import pandas as pd
from datetime import datetime, timedelta, timezone
from pandas import DataFrame
from typing import Dict, Optional, Union, Tuple

from freqtrade.strategy import (
    IStrategy,
    Trade,
    Order,
    PairLocks,
    informative,
    BooleanParameter,
    CategoricalParameter,
    DecimalParameter,
    IntParameter,
    RealParameter,
    timeframe_to_minutes,
    timeframe_to_next_date,
    timeframe_to_prev_date,
    merge_informative_pair,
    stoploss_from_absolute,
    stoploss_from_open,
    AnnotationType,
)

import talib.abstract as ta
from technical import qtpylib


class AggressiveScalpStrategy(IStrategy):
    """
    Profitable momentum strategy with trend filtering.
    Uses multiple confirmations to enter high-probability trades.
    """
    
    INTERFACE_VERSION = 3

    # 5-minute timeframe - good balance between signal quality and trade frequency
    timeframe = "5m"

    can_short: bool = False

    # Conservative ROI - let winners run
    minimal_roi = {
        "0": 0.05,    # 5% target
        "30": 0.03,   # 3% after 30 min
        "60": 0.02,   # 2% after 1 hour
        "120": 0.01   # 1% after 2 hours
    }

    # Wider stoploss to avoid getting stopped out on noise
    stoploss = -0.05  # 5% stop loss

    # Dynamic trailing stop
    trailing_stop = True
    trailing_only_offset_is_reached = True
    trailing_stop_positive = 0.01  # Start trailing at 1%
    trailing_stop_positive_offset = 0.025  # Offset of 2.5%

    process_only_new_candles = True

    # Only exit on strong signals, let ROI/trailing handle profits
    use_exit_signal = True
    exit_profit_only = True  # Only exit on signal if in profit
    ignore_roi_if_entry_signal = False

    startup_candle_count: int = 50

    # Limit orders for better prices
    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False
    }

    order_time_in_force = {
        "entry": "GTC",
        "exit": "GTC"
    }

    @property
    def plot_config(self):
        return {
            "main_plot": {
                "ema_short": {"color": "blue"},
                "ema_medium": {"color": "orange"},
                "ema_long": {"color": "red"},
            },
            "subplots": {
                "RSI": {
                    "rsi": {"color": "red"},
                },
                "MACD": {
                    "macd": {"color": "blue"},
                    "macdsignal": {"color": "orange"},
                }
            }
        }

    def informative_pairs(self):
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Quality indicators for trend and momentum detection
        """
        # Multiple EMAs for trend detection
        dataframe["ema_short"] = ta.EMA(dataframe, timeperiod=8)
        dataframe["ema_medium"] = ta.EMA(dataframe, timeperiod=21)
        dataframe["ema_long"] = ta.EMA(dataframe, timeperiod=50)

        # RSI for momentum
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)

        # MACD for momentum confirmation
        macd = ta.MACD(dataframe, fastperiod=12, slowperiod=26, signalperiod=9)
        dataframe["macd"] = macd["macd"]
        dataframe["macdsignal"] = macd["macdsignal"]
        dataframe["macdhist"] = macd["macdhist"]

        # Bollinger Bands for volatility
        bollinger = qtpylib.bollinger_bands(qtpylib.typical_price(dataframe), window=20, stds=2)
        dataframe["bb_lowerband"] = bollinger["lower"]
        dataframe["bb_middleband"] = bollinger["mid"]
        dataframe["bb_upperband"] = bollinger["upper"]
        dataframe["bb_width"] = (dataframe["bb_upperband"] - dataframe["bb_lowerband"]) / dataframe["bb_middleband"]

        # ADX for trend strength
        dataframe["adx"] = ta.ADX(dataframe, timeperiod=14)

        # Volume analysis
        dataframe["volume_mean"] = dataframe["volume"].rolling(window=20).mean()
        dataframe["volume_ratio"] = dataframe["volume"] / dataframe["volume_mean"]

        # ATR for volatility
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=14)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Multiple confirmations required for entry:
        - Strong uptrend (EMA alignment)
        - Momentum confirmation (RSI + MACD)
        - Volume support
        - Pullback entry (price near support)
        """
        dataframe.loc[
            (
                # Trend confirmation - EMAs aligned bullish
                (dataframe["ema_short"] > dataframe["ema_medium"]) &
                (dataframe["ema_medium"] > dataframe["ema_long"]) &
                
                # Strong trend strength
                (dataframe["adx"] > 25) &
                
                # Momentum building
                (dataframe["rsi"] > 40) &
                (dataframe["rsi"] < 70) &  # Not overbought
                
                # MACD bullish
                (dataframe["macd"] > dataframe["macdsignal"]) &
                (dataframe["macdhist"] > 0) &
                
                # Price action - pullback to support
                (
                    # Either near lower BB or EMA support
                    (dataframe["close"] <= dataframe["bb_middleband"]) |
                    (dataframe["close"] <= dataframe["ema_short"] * 1.005)
                ) &
                
                # Volume confirmation
                (dataframe["volume_ratio"] > 1.0) &
                
                # Price starting to move up
                (dataframe["close"] > dataframe["close"].shift(1)) &
                
                (dataframe["volume"] > 0)
            ),
            "enter_long"] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Exit only on strong reversal signals - let trailing stop handle most exits
        """
        dataframe.loc[
            (
                # Strong reversal signals
                (
                    # Trend breaking - EMAs starting to cross down
                    (dataframe["ema_short"] < dataframe["ema_medium"]) |
                    
                    # Momentum weakening significantly
                    (
                        (dataframe["rsi"] > 75) &  # Very overbought
                        (dataframe["rsi"] < dataframe["rsi"].shift(1))  # Starting to decline
                    ) |
                    
                    # MACD bearish cross
                    (
                        (dataframe["macd"] < dataframe["macdsignal"]) &
                        (dataframe["macd"].shift(1) >= dataframe["macdsignal"].shift(1))
                    )
                ) &
                
                (dataframe["volume"] > 0)
            ),
            "exit_long"] = 1

        return dataframe