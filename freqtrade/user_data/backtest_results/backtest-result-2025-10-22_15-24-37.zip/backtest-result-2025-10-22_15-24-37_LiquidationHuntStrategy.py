from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta

class LiquidationHuntStrategy(IStrategy):
    timeframe = '15m'
    can_short = False
    
    minimal_roi = {"0": 0.02}
    stoploss = -0.02
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe)
        dataframe['volume_mean'] = dataframe['volume'].rolling(20).mean()
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['rsi'] < 30) & 
            (dataframe['volume'] > dataframe['volume_mean']),
            'enter_long'
        ] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            dataframe['rsi'] > 60,
            'exit_long'
        ] = 1
        return dataframe