# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
# --- Do not remove these imports ---
import numpy as np
import pandas as pd
from datetime import datetime, timedelta, timezone
from pandas import DataFrame
from typing import Dict, Optional, Union, Tuple

from freqtrade.strategy import (
    IStrategy,
    Trade,
    Order,
    PairLocks,
    informative,
    BooleanParameter,
    CategoricalParameter,
    DecimalParameter,
    IntParameter,
    RealParameter,
    timeframe_to_minutes,
    timeframe_to_next_date,
    timeframe_to_prev_date,
    merge_informative_pair,
    stoploss_from_absolute,
    stoploss_from_open,
    AnnotationType,
)

import talib.abstract as ta
from technical import qtpylib


class AggressiveScalpStrategy(IStrategy):
    """
    Ultra-aggressive scalping strategy for rapid testing.
    WARNING: This strategy is designed to generate many trades quickly.
    It will rack up trading fees very fast and likely deplete balance.
    Perfect for testing bot functionality and order execution.
    """
    
    INTERFACE_VERSION = 3

    # 1-minute timeframe for maximum trade frequency
    timeframe = "1m"

    can_short: bool = False

    # Very aggressive ROI - take tiny profits immediately
    minimal_roi = {
        "0": 0.008,   # 0.8% profit target
        "3": 0.005,   # 0.5% after 3 minutes
        "8": 0.003,   # 0.3% after 8 minutes
        "15": 0.001   # 0.1% after 15 minutes
    }

    # Tight stoploss to trigger frequently
    stoploss = -0.025  # 2.5% stop loss

    # Aggressive trailing stop
    trailing_stop = True
    trailing_only_offset_is_reached = True
    trailing_stop_positive = 0.003  # Start trailing at 0.3%
    trailing_stop_positive_offset = 0.006  # Offset of 0.6%

    process_only_new_candles = True

    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    startup_candle_count: int = 20

    # Limit orders (works without config changes)
    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False
    }

    order_time_in_force = {
        "entry": "GTC",
        "exit": "GTC"
    }

    @property
    def plot_config(self):
        return {
            "main_plot": {
                "ema_fast": {"color": "blue"},
                "ema_slow": {"color": "red"},
            },
            "subplots": {
                "RSI": {
                    "rsi": {"color": "red"},
                }
            }
        }

    def informative_pairs(self):
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Minimal indicators for fast execution
        """
        # Ultra-fast RSI
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=5)

        # Very fast EMAs
        dataframe["ema_fast"] = ta.EMA(dataframe, timeperiod=3)
        dataframe["ema_slow"] = ta.EMA(dataframe, timeperiod=8)

        # Fast Bollinger Bands
        bollinger = qtpylib.bollinger_bands(qtpylib.typical_price(dataframe), window=10, stds=1.5)
        dataframe["bb_lowerband"] = bollinger["lower"]
        dataframe["bb_middleband"] = bollinger["mid"]
        dataframe["bb_upperband"] = bollinger["upper"]

        # Fast Stochastic
        stoch_fast = ta.STOCHF(dataframe, fastk_period=5, fastd_period=3)
        dataframe["fastd"] = stoch_fast["fastd"]
        dataframe["fastk"] = stoch_fast["fastk"]

        # MACD with fast settings
        macd = ta.MACD(dataframe, fastperiod=6, slowperiod=13, signalperiod=5)
        dataframe["macd"] = macd["macd"]
        dataframe["macdsignal"] = macd["macdsignal"]

        # Volume spike detection
        dataframe["volume_mean"] = dataframe["volume"].rolling(window=10).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Very loose entry conditions - enters on multiple weak signals
        """
        dataframe.loc[
            (
                # Condition 1: RSI oversold (very loose threshold)
                (dataframe["rsi"] < 40) |
                
                # Condition 2: Fast EMA crosses above slow
                (
                    (dataframe["ema_fast"] > dataframe["ema_slow"]) &
                    (dataframe["ema_fast"].shift(1) <= dataframe["ema_slow"].shift(1))
                ) |
                
                # Condition 3: Price touches lower BB
                (dataframe["close"] <= dataframe["bb_lowerband"] * 1.003) |
                
                # Condition 4: Stochastic oversold
                (dataframe["fastk"] < 25) |
                
                # Condition 5: MACD crosses above signal
                (
                    (dataframe["macd"] > dataframe["macdsignal"]) &
                    (dataframe["macd"].shift(1) <= dataframe["macdsignal"].shift(1))
                ) |
                
                # Condition 6: Volume spike
                (dataframe["volume"] > dataframe["volume_mean"] * 1.3)
            ) &
            (dataframe["volume"] > 0)
            ,
            "enter_long"] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Quick exit on any reversal signal
        """
        dataframe.loc[
            (
                # Exit 1: RSI overbought
                (dataframe["rsi"] > 65) |
                
                # Exit 2: Fast EMA crosses below slow
                (
                    (dataframe["ema_fast"] < dataframe["ema_slow"]) &
                    (dataframe["ema_fast"].shift(1) >= dataframe["ema_slow"].shift(1))
                ) |
                
                # Exit 3: Price touches upper BB
                (dataframe["close"] >= dataframe["bb_upperband"] * 0.997) |
                
                # Exit 4: Stochastic overbought
                (dataframe["fastk"] > 75) |
                
                # Exit 5: MACD crosses below signal
                (
                    (dataframe["macd"] < dataframe["macdsignal"]) &
                    (dataframe["macd"].shift(1) >= dataframe["macdsignal"].shift(1))
                )
            ) &
            (dataframe["volume"] > 0)
            ,
            "exit_long"] = 1

        return dataframe